Must need for this project:
---------------------------
1. Arduino uno
2.Bluetooth module
3.Relay
4.some ware



Output pin:
-------------
light1-----> 2 no arduno pin
light1-----> 3 no arduno pin
light1-----> 4 no arduno pin
light1-----> 5 no arduno pin

Fan1-------> 6 no arduno pin
Fan1-------> 7 no arduno pin
Fan1-------> 8 no arduno pin
Fan1-------> 9 no arduno pin

TV-------> 10 no arduno pin
SW1-------> 11 no arduno pin
SW2-------> 12 no arduno pin

